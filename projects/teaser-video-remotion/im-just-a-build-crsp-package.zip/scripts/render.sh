#!/usr/bin/env bash
# Local-only: requires Node, npm, FFmpeg, and npm install in this directory.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "render.sh: node is required on PATH"
  exit 1
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "render.sh: npm is required on PATH"
  exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "render.sh: ffmpeg is required on PATH for Remotion encoding"
  exit 1
fi

mkdir -p dist
exec npx remotion render src/index.ts ImJustABuild dist/im-just-a-build.mp4
