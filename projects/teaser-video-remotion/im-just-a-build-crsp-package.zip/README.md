# I’m Just a Build

## Deterministic Remotion teaser video inside TLC

“I’m Just a Build” is a Remotion subproject housed inside TLC. It is a constitutional remake-homage of the pedagogical structure behind “I’m Just a Bill,” reframed around C-RSP build discipline: uncertainty -> regulation -> proof -> legitimacy.

## Why this exists inside TLC

This package functions as a front-door teaser artifact for the broader constitutional operating model. It translates abstract governance concepts into a short narrative object that is easier to see, explain, demo, and eventually publish. The video is not a separate product platform. It is a bounded, isolated media subproject inside TLC.

## Fixed format

- **Canvas:** 1080x1080
- **Duration:** 60 seconds
- **FPS:** 12
- **Total frames:** 720

## Style

- 1970s Schoolhouse Rock-inspired cel-animation homage
- flat shapes
- hard outlines
- mustard / olive / burnt-orange palette
- deterministic analog-feeling wobble
- no glossy modern motion-graphics look

## Story structure

1. **Act I — Concept**
2. **Act II — Mechanism**
3. **Act III — 10 Pillars**
4. **Act IV — Validation / Resolution**

## Runtime requirements

Install locally:

- Node.js
- npm
- FFmpeg (required for `npm run render` / Remotion encoding)
- Remotion-compatible environment

Claude Code is **not** required to run this project.

## Install

From the TLC repo root:

```bash
cd projects/teaser-video-remotion
npm install
```

## Preview (Remotion Studio)

```bash
npm run dev
```

## Render locally

```bash
npm run render
```

This invokes `scripts/render.sh`, which checks for `node`, `npm`, and `ffmpeg`, then runs Remotion render.

**Expected output path after a successful local render:**

`projects/teaser-video-remotion/dist/im-just-a-build.mp4`

The `dist/` directory and MP4 file are **not** source artifacts; they appear only after a successful render on your machine.

## Package ZIP locally

```bash
npm run package:zip
```

**Expected output path after a successful local packaging run:**

`projects/teaser-video-remotion/im-just-a-build-crsp-package.zip`

The script excludes `node_modules/` and `dist/` to keep the archive small; run `npm install` after unzipping.

## Lint

```bash
npm run lint
```

Runs `tsc --noEmit`.

## Deterministic guarantee

Project source must not use `Math.random()`. All jitter and analog-feeling motion are generated through seeded frame-based logic (`src/lib/deterministic.ts`) so repeated renders from the same source remain reproducible. (Tooling under `node_modules/` may use randomness; that is outside this package’s source contract.)

## Core authored documents

- `BUILD_CONTRACT.md` — executable build contract
- `CLAUDE.md` — repo-local operating overlay
- `DIRECTORS_TREATMENT.md` — concept, staging, and motion direction
- `LYRICS_TIMECODE.md` — lyric and caption timing map
- `VISUAL_INVARIANTS.md` — non-drifting style rules

## Truth discipline

This package can exist before the MP4 exists. The code and documents are source artifacts. The rendered video and ZIP archive only exist after local execution of the relevant commands.
